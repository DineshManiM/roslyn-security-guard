﻿This directory contains the rich descriptions of each vulnerability.

The HTML descriptions are only used for the static website.
They are not bundle in the final package VSIX.
